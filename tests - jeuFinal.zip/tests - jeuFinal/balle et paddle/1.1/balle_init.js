//test balle + paddle
window.onload = function()
{
    var canvas = document.getElementById("myCanvas");
    if(!canvas)
    {
        alert("Impossible de récupérer le canvas");
        return;
    }
    
    var context = canvas.getContext("2d");
    if(!context)
    {
        alert("Impossible de récupérer le context");
        return;
    }
    //Init : ball   
    var diametreBalle = 20;
    
    var posX = 1+diametreBalle/2;
    var posY = 1+diametreBalle/2;
    var vitesseX = 3;
    var vitesseY = 3;
    
    //etat play = %2 == 1 sinon pause
    var etat = 2;    
    
//--Création des paddles--//
	//definition du type paddle 
	 function paddle(longueur,hauteur,vitesse,x,y,couleur){
		this.longueur = longueur;
		this.hauteur = hauteur;
		this.vitesse = vitesse;
		this.x = x;
		this.y = y;
		this.Init = Init;
		this.animate = animate;
		this.Dessin = Dessin;
		this.couleur = couleur;
	}
	
//Init paddle
	function Init(context,canvas){
		this.x = canvas.width/2;
		this.y = canvas.height - 5;
	}
	
//Dessin du paddle
	function Dessin(context,canvas){
		context.fillRect(this.x,this.y,this.longueur,this.hauteur); //creation du block
		context.fill();
		context.fillStyle = this.couleur;
		//context.clearRect(this.x,this.y,this.longueur,this.hauteur);
	}	
	
//Mouvement du paddle (dans la fonction animate) :
	function animate(canvas,context){
		window.addEventListener("keydown", function (event) {
 		if (event.defaultPrevented) {
    			return; // Should do nothing if the key event was already consumed.
  		}

  		switch (event.key) {
				case "ArrowRight": //droite
					if(this.x + this.longueur == canvas.width){
						break;
					}
					else{
						p.x += p.vitesse;
						context.clearRect(0,0,canvas.width,canvas.height);
						break;
					}
				case "ArrowLeft": //gauche
					if(this.x - this.longueur == 0){
						break;
					}
					else{
						p.x -= p.vitesse;
						context.clearRect(0,0,canvas.width,canvas.height);
						break;
					}
				case "ArrowUp": //haut play/pause
					if(etat%2 == 0){
						vitesseX *=0;
						vitesseY *=0;
						//p.vitesse *=0;
						etat +=1;
						break;
					}
					else{
						vitesseX +=3;
						vitesseY +=3;
						etat +=1;
						break;
					}
				case "ArrowDown"://diminuer vitesse ball
						vitesseX *=1.2;
						vitesseY *=1.2;
						p.vitesse *=1.2;
						break;
				/*case "ArrowDown"://augmenter vitesse ball
						vitesseX /=1.2;
						vitesseY /=1.2;
						p.vitesse /=1.2;
						break;*/
				
				default:
  				    return; // Quit when this doesn't handle the key event.
 				 }
			 event.preventDefault();
			}, true);
		}

    //Init paddle :
	var p = new paddle(200,10,5,canvas.width/2 - 100,canvas.height - 20,"#123");
	p.Dessin(context,canvas);
		
    var myInterval = setInterval(anim, 1000/30);
    function anim()
    {
   	p.animate(canvas,context);
	p.Dessin(context,canvas);
          
        //Tracé de la balle
        context.clearRect(0,0,canvas.width,canvas.height-20);
        context.beginPath();
        context.arc(posX, posY, diametreBalle/2, 0, Math.PI*2);
        context.fill();
        
        //On va vérifier si la balle à toucher l'un des bords du canvas.
        if(posX+diametreBalle/2 >= canvas.width || posX <= 0+diametreBalle/2)//Si on touche le bord gauche ou droit
        {
            vitesseX *= -1;//On inverse la vitesse de déplacement sur l'axe horizontal.
           // context.fillStyle="blue";
	    var degrade = context.createLinearGradient(0,0,200,100);
            degrade.addColorStop(0,"#123");//Ajout d'une première couleur.
    	    degrade.addColorStop(1,"#999");//Ajout de la seconde couleur.
	    context.fillStyle = degrade;
	//    context.font = "25px Arial";	
	//    context.fillText("DE POULE",canvas.width/2 -10,canvas.height/2 -200 );

        }
        if(posY <= 0+diametreBalle/2)//Si on touche le bord du bas ou du haut
        {
            vitesseY *= -1;//On inverse la vitesse de déplacement sur l'axe vertical.
          //  context.fillStyle="red";
          var degrade = context.createLinearGradient(0,0,300,200);
          degrade.addColorStop(0,"#999");//Ajout d'une première couleur.
    	  degrade.addColorStop(1,"#123");//Ajout de la seconde couleur.
	  context.fillStyle = degrade;
	//  context.font = "25px Arial";	
	// context.fillText("DE POULE",canvas.width/2 -10,canvas.height/2 -200 );

        }
        if(posY+diametreBalle/2 >=canvas.height){
        	vitesseX *=0;
        	vitesseY *=0;
		p.vitesse *=0;
        	context.font = "25px Helvetica";	
		context.fillText("Vous avez perdu",canvas.width/2 - 160,canvas.height/2 -20);
		context.fillText("Appuyez sur ENTRER pour relancer",canvas.width/2 - 160,canvas.height/2);
		window.addEventListener("keydown", function (event) {
 			if (event.defaultPrevented) {
    				return; // Should do nothing if the key event was already consumed.
  			}
  			if (event.key == "Enter") {
				location.reload();
			}
		},true);
	}
	//collision
	//if((posY +diametreBalle/2 <= p.y)&&((posX+diametreBalle/2 >= p.x) && (posX + diametreBalle/2<=p.longueur))){
	for(var i=0;i<=p.longueur;i++){
		if(posX + diametreBalle/2 == p.x+i){
			if(posY + diametreBalle/2 == p.y-p.hauteur){ 
				vitesseY *= -1;
				//context.font = "25px Helvetica";	
				//context.fillText("SWAG!",canvas.width/2 -100 ,canvas.height/2 -200 );
        
			}
		}
	}
	context.fillRect(200,0,400,5);
	//Pour gagner touchez 4 fois la reglette en haut de l'ecran
	var compteur = 0;
	if(posX >= 200){
		if(posX <= 600){ 
			if(posY <= diametreBalle/2){
				compteur += 1;
				context.fillRect(200,0,400,10);
			}
		}
	}
	if(compteur == 4){
		vitesseX *=0;
        	vitesseY *=0;
		context.font = "20px Helvetica";	
		context.fillText("SWAG! Vous avez gagne! ",canvas.width/2 - 160,canvas.height/2 -20);
		context.fillText("Appuyez sur ENTRER pour relancer",canvas.width/2 - 160,canvas.height/2);
		window.addEventListener("keydown", function (event) {
 			if (event.defaultPrevented) {
    				return; // Should do nothing if the key event was already consumed.
  			}
  			if (event.key == "Enter") {
				location.reload();
			}
		},true);
	}
		
	context.font = "12px Helvetica";		
	context.fillText("Fleche du haut pour play/pause",40,10);
	context.fillText("Fleche du bas pour augmenter la vitesse de balle",40,25);
	context.fillText("Touchez 4 fois la reglette du haut pour gagner",40,40);
			

  	

        //On additionne les vitesses de déplacement avec les positions
        posX += vitesseX*(1.5);
        posY += vitesseY*(1.5);
        }
        
}
	

    

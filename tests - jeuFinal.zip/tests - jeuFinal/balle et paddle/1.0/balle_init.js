//test balle + paddle
window.onload = function()
{
    var canvas = document.getElementById("myCanvas");
    if(!canvas)
    {
        alert("Impossible de récupérer le canvas");
        return;
    }
    
    var context = canvas.getContext("2d");
    if(!context)
    {
        alert("Impossible de récupérer le context");
        return;
    }
    //Init : ball   
    var diametreBalle = 20;
    
    var posX = 1+diametreBalle/2;
    var posY = 1+diametreBalle/2;
    var vitesseX = 3;
    var vitesseY = 3;
    
    
//--Création des paddles--//
	//definition du type paddle 
	 function paddle(longueur,hauteur,vitesse,x,y,couleur){
		this.longueur = longueur;
		this.hauteur = hauteur;
		this.vitesse = vitesse;
		this.x = x;
		this.y = y;
		this.Init = Init;
		this.animate = animate;
		this.Dessin = Dessin;
		this.couleur = couleur;
	}
	
//Init paddle
	function Init(context,canvas){
		this.x = canvas.width/2;
		this.y = canvas.height - 5;
	}
	
//Dessin du paddle
	function Dessin(context,canvas){
		context.fillRect(this.x,this.y,this.longueur,this.hauteur); //creation du block
		context.fill();
		context.fillStyle = this.couleur;
		//context.clearRect(this.x,this.y,this.longueur,this.hauteur);
	}	
	
//Mouvement du paddle (dans la fonction animate) :
	function animate(canvas,context){
		window.addEventListener("keydown", function (event) {
 		if (event.defaultPrevented) {
    			return; // Should do nothing if the key event was already consumed.
  		}

  		switch (event.key) {
				case "ArrowRight": //droite
					if(this.x + this.longueur == canvas.width){
						break;
					}
					else{
						p.x += p.vitesse;
						context.clearRect(0,0,canvas.width,canvas.height);
						break;
					}
				case "ArrowLeft": //gauche
					if(this.x - this.longueur == 0){
						break;
					}
					else{
						p.x -= p.vitesse;
						context.clearRect(0,0,canvas.width,canvas.height);
						break;
					}
				  default:
  				    return; // Quit when this doesn't handle the key event.
 				 }
			 event.preventDefault();
			}, true);
		}
		
    //Init paddle :
	var p = new paddle(200,10,5,canvas.width/2 - 100,canvas.height - 20,"#123");
	p.Dessin(context,canvas);
		
    var myInterval = setInterval(anim, 1000/30);
    function anim()
    {
   	p.animate(canvas,context);
	p.Dessin(context,canvas);
          
        //Tracé de la balle
        context.clearRect(0,0,canvas.width,canvas.height-20);
        context.beginPath();
        context.arc(posX, posY, diametreBalle/2, 0, Math.PI*2);
        context.fill();
        
        //On va vérifier si la balle à toucher l'un des bords du canvas.
        if(posX+diametreBalle/2 >= canvas.width || posX <= 0+diametreBalle/2)//Si on touche le bord gauche ou droit
        {
            vitesseX *= -1;//On inverse la vitesse de déplacement sur l'axe horizontal.
           // context.fillStyle="blue";
	    var degrade = context.createLinearGradient(0,0,200,100);
            degrade.addColorStop(0,"#123");//Ajout d'une première couleur.
    	    degrade.addColorStop(1,"#999");//Ajout de la seconde couleur.
	    context.fillStyle = degrade;
        }
        if(posY <= 0+diametreBalle/2)//Si on touche le bord du bas ou du haut
        {
            vitesseY *= -1;//On inverse la vitesse de déplacement sur l'axe vertical.
          //  context.fillStyle="red";
          var degrade = context.createLinearGradient(0,0,300,200);
          degrade.addColorStop(0,"#999");//Ajout d'une première couleur.
    	  degrade.addColorStop(1,"#123");//Ajout de la seconde couleur.
	  context.fillStyle = degrade;
        }
        if(posY+diametreBalle/2 >=canvas.height){
        	vitesseX *=0;
        	vitesseY *=0;
			p.vitesseX *=0;
			p.vitesseY *= 0;
        	context.font = "18px Helvetica";	
		context.fillText("Vous avez perdu",canvas.width/2 - 160,canvas.height/2 -20);
		context.fillText("Appuyez sur ENTRER pour relancer",canvas.width/2 - 160,canvas.height/2);
		window.addEventListener("keydown", function (event) {
 			if (event.defaultPrevented) {
    				return; // Should do nothing if the key event was already consumed.
  			}
  			if (event.key == "Enter") {
				location.reload();
			}
		},true);
	}
	//collision
	//if((posY +diametreBalle/2 <= p.y)&&((posX+diametreBalle/2 >= p.x) && (posX + diametreBalle/2<=p.longueur))){
	for(var i=0;i<=p.longueur;i++){
		if(posX + diametreBalle/2 == p.x+i){
			if(posY + diametreBalle/2 == p.y-p.hauteur){ 
				vitesseY *= -1;
			}
		}
	}
        
        //On additionne les vitesses de déplacement avec les positions
        posX += vitesseX*(1.5);
        posY += vitesseY*(1.5);
        }
        
}
	

    

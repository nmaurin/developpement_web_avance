//Test paddle//
window.onload = function()
{
    var canvas = document.getElementById("myCanvas");   
    var context = canvas.getContext("2d");
//--Création des paddles--//
	//definition du type paddle 
	 function paddle(longueur,hauteur,vitesse,x,y,couleur){
		this.longueur = longueur;
		this.hauteur = hauteur;
		this.vitesse = vitesse;
		this.x = x;
		this.y = y;
		this.Init = Init;
		this.animate = animate;
		this.collision = collision;
		this.Dessin = Dessin;
		this.couleur = couleur;
	}
	
//Init paddle
	function Init(context,canvas){
		this.x = canvas.width/2;
		this.y = canvas.height - 5;
	}
	
//Dessin du paddle
	function Dessin(context,canvas){
		context.fillRect(this.x,this.y,this.longueur,this.hauteur); //creation du block
		context.fill();
		context.fillStyle = this.couleur;
		//context.clearRect(this.x,this.y,this.longueur,this.hauteur);
	}		
//Collision balle / paddle : dans la fonction animate
	function collision(ball){
		for(var i=0;i<this.longueur;i++){
			if(ball.x+ball.diametre/2 == this.x + i){//si la balle rencontre la paddle, on verse sa direction
				ball.vitesseX *= -1;
			}
		}
	}
	
//Mouvement du paddle (dans la fonction animate) :
	function animate(canvas,context){
		window.addEventListener("keydown", function (event) {
 		if (event.defaultPrevented) {
    			return; // Should do nothing if the key event was already consumed.
  		}

  		switch (event.key) {
				case "ArrowRight": //droite
					p.x += p.vitesse;
					context.clearRect(0,0,canvas.width,canvas.height);
					if(this.x + this.longueur == canvas.width){
						this.x = canvas.width - this.longueur;
					}
					else{
						this.x += this.vitesse;
					}
					break;
				case "ArrowLeft": //gauche
					p.x -= p.vitesse;
					context.clearRect(0,0,canvas.width,canvas.height);
					if(this.x - this.longueur == 0){
						this.x = this.longueur;
					}
					else{
						this.x -= this.vitesse;
					}
					break;
				  default:
      return; // Quit when this doesn't handle the key event.
  }
			 event.preventDefault();
}, true);
		}
		
//fonction :génère aléatoirement la couleur du paddle
	function getRandomColor(){
		var letters = '0123456789ABCDEF'.split('');
		var color = '#';
		var i;
		for(i=0;i<6;i++){
			color += letters[Math.floor(Math.random()*16)];
		}
		return color;
	}

//Init paddle :
	var p = new paddle(200,10,5,canvas.width/2 - 100,canvas.height - 20,"#123");
	p.Dessin(context,canvas);
		
    var myInterval = setInterval(animae, 1000/30);
    function animae()
    {
	p.animate(canvas,context);
	p.Dessin(context,canvas);
	}
} 	


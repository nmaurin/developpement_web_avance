//--Création de l'objet score--//
	//definiton du type score
	function score(perteBall,nbPerte,PointMax,PerteMax,Point,pause){
		//this.perteBall;//boolean a true si on perd la balle
		//this.nbPerte;//nombre de perte de balle
		this.PointMax = 12; //nombre de brique
		this.PerteMax = 3; //nb de perte de balle max admise
		//this.Point;//nb de brique cassé
		//this.pause;//pause : 1 play : 2
		this.Init = Init;
		this.perte = perte;
	}
	//Init score :
	function Init(){
		this.perteBall = false;
		this.nbPerte = 0;
		//this.PointMax = 12; 
		//this.PerteMax = 3;
		this.Point = 0;
		this.pause = 1;
	}
	
	//Perte de la balle : dans la fonction animate
	function perte(canvas,context){
		if(ball.y+ball.diametre/2 >= canvas.height){//on sort du canvas
			this.pause = 1;//on met en pause
			this.perteBall = true;
			this.nbPerte -= 1;
			context.fillText("Appuyez sur ENTRER pour relancer",canvas.width/2 - 160,canvas.height/2);
			canvas.addEventListener("onkeydown", function (event) {
			if ((keycode == 13 || 32) && (this.pause == 1)) {
					ball.Init(context,canvas);//On remet la balle sur le paddle
					ball.Dessin(canvas,context);
					paddle.Init(ball,canvas,context);//on remet le paddle au centre
 					pause = 2;//on met le jeu en play
					}
				},false);
			if(this.nbPerte == this.PerteMax){	
				context.font = "18px Helvetica";	
				context.fillText("Vous avez perdu",canvas.width/2 - 160,canvas.height/2 -20);
				context.fillText("Appuyez sur ENTRER pour relancer",canvas.width/2 - 160,canvas.height/2);
				window.onkeydown = function(event){
				if((key == 13 || key == 32)&&(this.play == 1)){//si on appuie sur entrer ou espace
					//reinit le jeu complet	
					context.clearRect(canvas.width/2,canvas.height/2,canvas.width,canvas.height); //on reinitialise tout
					InitBrique();//reinitialisation des briques.
					ball.Init(context,canvas);//reinitialisation de la balle
					ball.Dessin(context,canvas);//dessin de la balle
					paddle.Init(context,canvas);//reinitialisation du paddle
					this.Init();//reinitialisation des scores.
 					pause = 2;//on met le jeu en play
					}
				}
			}
		}
	}
		 

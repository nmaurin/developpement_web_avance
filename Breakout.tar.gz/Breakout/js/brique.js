//--création des briques--//
	//définition du type brique :
	function brique(longueur,hauteur,x,y,durete){//x,y:position du coin haut,gauche; durete permet se savoir combien de coup il faut pour casser la brique (int[1,5])
		this.longueur = 100;
		this.hauteur = 50;
		this.x = x;
		this.y = y;
		this.durete = durete;
		this.DessinBrique = DessinBrique;
		this.collision = collision;
	}
	
//fonction initialisation
	Initbrique = function(){
		var l = 100;
		var h = 50;
		var b1 = new brique(l,h,0,5,1);
		var b2 = new brique(l,h,100,5,2);
		var b3 = new brique(l,h,200,5,2);
		var b4 = new brique(l,h,300,5,1);
		var b5 = new brique(l,h,500,5,1);
		var b6 = new brique(l,h,600,5,2);
		var b7 = new brique(l,h,700,5,2);
		var b8 = new brique(l,h,800,5,1);
			
		var b9 = new brique(l,h,150,60,3);
		var b10 = new brique(l,h,350,60,3);
		var b11 = new brique(l,h,550,60,3);
		var b12 = new brique(l,h,750,60,3);
		
		b1.DessinBrique(context,canvas);
		b2.DessinBrique(context,canvas);
		b3.DessinBrique(context,canvas);
		b4.DessinBrique(context,canvas);
		b5.DessinBrique(context,canvas);
		b6.DessinBrique(context,canvas);
		b7.DessinBrique(context,canvas);
		b8.DessinBrique(context,canvas);
		b9.DessinBrique(context,canvas);
		b10.DessinBrique(context,canvas);
		b11.DessinBrique(context,canvas);
		b12.DessinBrique(context,canvas);
		
	}
	
//fonction : Création des blocs de briques
	function DessinBrique(context,canvas){
		context.fillRect(this.x,this.y,this.longueur,this.hauteur); //creation du block
		if(this.durete == 0)
			context.clearRect(this.x,this.y,this.longueur,this.hauteur);//clear de l'espace
		if(this.durete == 1)
			context.fillStyle = "blue";//changement de couleur.
		if(this.durete == 2)
			context.fillStyle = "green";
		if(this.durete == 3)
			context.fillStyle = "purple";
		if(this.durete == 4)
			context.fillStyle = "black";
		}

			
//Collision : dans la fonction animate
	 function collision(context,canvas,ball){
		if(this.durete > 0){//sinon la brique n'existe pas
			for(var i=0;i<=this.longueur;i++){
				if((this.x + i == ball.x + ball.diametre/2) && (this.y == ball.y + ball.diametre/2)){//si il y a collision (partie haute de la brique)  on diminue la durete et on change de couleur la brique
					this.durete -= 1; //diminution du nombre de coups à porter avant destruction de la brique
					this.DessinBrique(context,canvas); //changement de couleur de la brique
					ball.vitesseX *= -1; //changement de direction de la balle	
				}
				if((this.x + i == ball.x + ball.diametre/2) && (this.y + this.hauteur == ball.y + ball.diametre/2)){//si il y a collision (partie basse de la brique) on diminue la durete et on change de couleur la brique
					this.durete -= 1;
					this.DessinBrique(context,canvas); 
					ball.vitesseY *= -1;
				}
			}
			for(var i=0;i<=this.hauteur;i++){
				if((this.x == ball.x + ball.diametre/2) && (this.y + i == ball.y + ball.diametre/2)){//si il y a collision (partie haute de la brique)  on diminue la durete et on change de couleur la brique
					this.durete -= 1;
					this.DessinBrique(context,canvas); 
					ball.vitesseY *= -1;
				}
				if((this.x + this.longueur == ball.x + ball.diametre/2) && (this.y + i == ball.y + ball.diametre/2)){//si il y a collision (partie basse de la brique) on diminue la durete et on change de couleur la brique
					this.durete -= 1;
					this.DessinBrique(context,canvas); 
					ball.vitesseY *= -1;
				}
			}
		}
	}
			
			
		


//Breakout//
function Game() {
	//Canvas :
	var canvas = document.getElementById("myCanvas");
	var context = canvas.getContext("2d");
	
	//Initialisations :
	var s = new score(false,0,12,3,0,1);
	var p = new paddle(200,2,2,canvas.width/2,canvas.height - 5);
	var b = new ball(20,2,2,p.x+p.longueur/2 - 10,p.y + p.hauteur/2 - 10);	
	b.Dessin(context,canvas);
	//Initbrique();
	//Init brique :
		var l = 50;
		var h = 25;
		var b1 = new brique(l,h,0,5,1);
		var b2 = new brique(l,h,100,5,2);
		var b3 = new brique(l,h,200,5,2);
		var b4 = new brique(l,h,300,5,1);
		var b5 = new brique(l,h,500,5,1);
		var b6 = new brique(l,h,600,5,2);
		var b7 = new brique(l,h,700,5,2);
		var b8 = new brique(l,h,800,5,1);
			
		var b9 = new brique(l,h,150,60,3);
		var b10 = new brique(l,h,350,60,3);
		var b11 = new brique(l,h,550,60,3);
		var b12 = new brique(l,h,750,60,3);
	//dessin des briques:
	
		b1.DessinBrique(context,canvas);
		b2.DessinBrique(context,canvas);
		b3.DessinBrique(context,canvas);
		b4.DessinBrique(context,canvas);
		b5.DessinBrique(context,canvas);
		b6.DessinBrique(context,canvas);
		b7.DessinBrique(context,canvas);
		b8.DessinBrique(context,canvas);
		b9.DessinBrique(context,canvas);
		b10.DessinBrique(context,canvas);
		b11.DessinBrique(context,canvas);
		b12.DessinBrique(context,canvas);
					

	
	//Boucle de jeu :
	var myInterval = setInterval(loop,100);
	function loop(){
		//requestAnimationFrame(animate);
		b.animate(canvas,context);
		b.Dessin(canvas,context);
		p.animate(canvas,context);
		b1.collision(context,canvas,b);
		b2.collision(context,canvas,b);
		b3.collision(context,canvas,b);
		b4.collision(context,canvas,b);
		b5.collision(context,canvas,b);
		b7.collision(context,canvas,b);
		b8.collision(context,canvas,b);
		b9.collision(context,canvas,b);
		b10.collision(context,canvas,b);
		b11.collision(context,canvas,b);
		b12.collision(context,canvas,b);
		p.collision(canvas,context);
		s.perte(canvas,context);
	}
	//animate();
}
window.onload = Game;

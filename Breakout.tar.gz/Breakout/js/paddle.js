//--Création des paddles--//
	//definition du type paddle 
	 function paddle(longueur,hauteur,vitesse,x,y){
		this.longueur = 200;
		this.hauteur = 2;
		this.vitesse = 2;
		this.x = x;
		this.y = y;
		this.Init = Init;
		this.animate = animate;
		this.collision = collision;
		this.Dessin = Dessin;
	}
	
//Init paddle
	function Init(context,canvas){
		this.x = canvas.width/2;
		this.y = canvas.height - 5;
	}
	
//Dessin du paddle
	function Dessin(context,canvas){
		context.fillRect(this.x,this.y,this.longueur,this.hauteur); //creation du block
		context.fill();
		context.fillStyle = getRandomColor();
		//context.clearRect(this.x,this.y,this.longueur,this.hauteur);
	}		
//Collision balle / paddle : dans la fonction animate
	function collision(ball){
		for(var i=0;i<this.longueur;i++){
			if(ball.x+ball.diametre/2 == this.x + i){//si la balle rencontre la paddle, on verse sa direction
				ball.vitesseX *= -1;
			}
		}
	}
	
//Mouvement du paddle (dans la fonction animate) :
	function animate(canvas,context){
		canvas.addEventListener("onkeydown", function (event) {
			switch (keycode) {
				case 39 : //droite
					if(this.x + this.longueur == canvas.width){
						this.x = canvas.width - this.longueur;
					}
					else{
						this.x += this.vitesse;
					}
				case 37 : //gauche
					if(this.x - this.longueur == 0){
						this.x = this.longueur;
					}
					else{
						this.x -= this.vitesse;
					}
				}
			},false);
		}

//--Création de l'objet ball--//
	//definition du type ball
	function ball(diametre,vitesseX,vitesseY,x,y){
		this.diametre = diametre;
		this.vitesseX = vitesseX;
		this.vitesseY = vitesseY;
		this.x = paddle.x+paddle.longueur/2 - this.diametre/2;//sur la paddle au milieu
		this.y = paddle.y+ paddle.hauteur/2 - this.diametre/2;
		this.Init = Init;
		this.animate = animate;
		this.Dessin = Dessin;
	}
	
//Init position de la balle :
	function Init(context,canvas){
		this.x = paddle.x+paddle.longueur/2 - this.diametre/2;//sur la paddle au milieu
		this.y = paddle.y+ paddle.hauteur/2 - this.diametre/2;
	}
	
//Dessin de la balle :	
	function Dessin(context,canvas){
		context.arc(this.x,this.y,this.diametre/2,0,Math.PI*2);
		context.fill();
		context.fillStyle = getRandomColor();
		//context.clearRect(this.x,this.y,this.x+this.diametre,this.x+this.diametre);
	}
	

//fonction :génère aléatoirement la couleur de la balle
	function getRandomColor(){
		var letters = '0123456789ABCDEF'.split('');
		var color = '#';
		var i;
		for(i=0;i<6;i++){
			color += letters[Math.floor(Math.random()*16)];
		}
		return color;
	}

//Mouvement de la balle (dans la boucle de jeu) :
	 function animate(canvas,context){
		//var canvas = document.getElementById('myCanvas');
		//var context = canvas.getContext('2d');
		
		//Gestion des deplacement :
		this.x += this.vitesseX;
		this.y += this.vitesseY;
		if(this.x+this.diametre/2 >= canvas.width || this.x+this.diametre/2 <= 0){
			this.vitesseX *= -1;
		}			 
		if(this.y+this.diametre/2 <= 0){
			this.vitesseY *= -1;	
		}
	}
	
	


